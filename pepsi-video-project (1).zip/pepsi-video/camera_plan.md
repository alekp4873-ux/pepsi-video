# Rencana kamera (sinkron kata)
| Shot | Waktu | Lokasi | Gerak |
|---|---|---|---|
| hook | 0.1-5.7 | Ruang belajar | Dorong dari meja ke siswa + papan tulis |
| contest | 6.0-11.3 | Jalan siang | Billboard KUMPULKAN POIN lalu dorong ke penjaga stan |
| ad | 11.7-18.0 | Ruang TV | Dorong ke layar TV, jet mendarat, harga muncul |
| stakes | 18.3-20.8 | Hanggar | Geser menyamping di sepanjang jet |
| math | 21.1-25.4 | Ruang belajar | Dorong ke papan tulis: 10¢ x 7.000.000 = $700.000 |
| check | 25.7-30.6 | Jalan siang | Tumpukan uang -> siswa -> kotak pos |
| but | 31.0-34.5 | Kantor Pepsi | Dorong ke meja, cek kembali, stempel LELUCON |
| yousee | 34.8-41.5 | Kantor Pepsi | Katalog: tidak ada jet, TIDAK ADA PENAWARAN |
| so | 41.8-48.3 | Ruang sidang | Meja penggugat -> hakim, ketukan palu |
| twist | 48.7-55.9 | Ruang TV | Iklan sama: 700.000.000 POIN + CUMA BERCANDA |

Potongan fade krem 0.4 dtk di tiap pindah lokasi (kecuali hook->contest start dan yousee).
