#!/usr/bin/env python3
"""Mixes synthesized sound effects into voiceover.wav, timed from src/timing.json + src/events.json
(the same word map the 3D scene uses). Reads voiceover_clean.wav, writes voiceover.wav."""
import json, subprocess, numpy as np
from scipy.signal import butter, lfilter
from scipy.io import wavfile
SR = 48000
T = json.load(open('src/timing.json')); EV = json.load(open('src/events.json'))
S = {s['key']: s for s in T['shots']}
def wordT(key, idx):
    s = S[key]; ws = s['text'].split()
    wt = [len(''.join(c for c in w if c.isalnum() or c == "'")) + 2 for w in ws]; tot = sum(wt)
    return s['start'] + (s['end'] - s['start']) * sum(wt[:idx]) / tot
E = {k: wordT(*v) for k, v in EV.items()}
keys = [s['key'] for s in T['shots']]
CONT = {'yousee'}
CUTS = [(T['shots'][i-1]['end'] + T['shots'][i]['start']) / 2 for i in range(1, len(keys)) if keys[i] not in CONT]
cut_of = {keys[i]: (T['shots'][i-1]['end'] + T['shots'][i]['start']) / 2 for i in range(1, len(keys))}

N = int(SR * (T['duration'] + 1)); mix = np.zeros(N)
rng = np.random.default_rng(7)
def put(x, t, g=1.0):
    i = int(t * SR); 
    if i < 0: i = 0
    j = min(N, i + len(x)); mix[i:j] += x[:j - i] * g
def env(n, a=0.01, d=0.2):
    t = np.arange(n) / SR; e = np.minimum(1, t / a) * np.exp(-t / d); return e
def tone(f0, f1, dur, d=0.1, a=0.004):
    n = int(SR * dur); t = np.arange(n) / SR; f = f0 + (f1 - f0) * t / dur
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, a, d)
def noise_band(dur, lo, hi, shape):
    n = int(SR * dur); x = rng.standard_normal(n)
    b, a = butter(2, [lo / (SR / 2), hi / (SR / 2)], btype='band'); x = lfilter(b, a, x)
    t = np.linspace(0, 1, n); return x / (np.abs(x).max() + 1e-9) * shape(t)
whoosh = lambda dur=0.45, lo=300, hi=5000: noise_band(dur, lo, hi, lambda t: np.sin(np.pi * t) ** 2)
def pop():   return tone(620, 1180, 0.16, 0.06) * 0.8
def ding():  return (tone(1568, 1568, 0.5, 0.16) + 0.5 * tone(2093, 2093, 0.5, 0.12)) * 0.6
def cha():   return ding() + 0.0
def thump(f=95):
    n = int(SR * 0.28); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * (f + 60 * np.exp(-t * 30)) * t) * np.exp(-t / 0.08) + 0.5 * rng.standard_normal(n) * np.exp(-t / 0.012)) * 0.9
def knock():
    n = int(SR * 0.22); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * 210 * t) * np.exp(-t / 0.035) + 0.7 * np.sin(2 * np.pi * 520 * t) * np.exp(-t / 0.02) + 0.4 * rng.standard_normal(n) * np.exp(-t / 0.006)) * 0.9
def scratch(): return noise_band(0.28, 2500, 9000, lambda t: (np.abs(np.sin(t * 22)) * np.exp(-t * 3)))
def static(dur=0.3): return noise_band(dur, 800, 12000, lambda t: (1 - t) * 0.6)
def boing(): return tone(900, 180, 0.5, 0.3, 0.01) * 0.8
def slide_up(): return tone(300, 1500, 0.45, 0.35, 0.01) * 0.7

# scene changes: whoosh on every cream dip
for c in CUTS: put(whoosh(0.5), c - 0.25, 0.55)
# TV shots start with a bit of static
put(static(0.25), cut_of['ad'] + 0.05, 0.25); put(static(0.25), cut_of['twist'] + 0.05, 0.25)
# hook / chalk
put(scratch(), E['posterPop'] - 0.2, 0.5); put(scratch(), E['chalk1'], 0.5); put(scratch(), E['chalk2'], 0.5)
# contest prizes
put(pop(), E['kaos'], 0.7); put(pop(), E['kacamata'], 0.7)
# ad: jet lands, price on screen
put(whoosh(1.4, 120, 3500), E['tvLand'] - 0.1, 0.7); put(thump(70), E['tvLand'] + 1.4, 0.6); put(ding(), E['tvPrice'], 0.7)
put(pop(), E['stakesSign'], 0.8)
# money + mailing
put(cha(), E['cash'] + 0.1, 0.8); put(pop(), E['chk'], 0.7); put(whoosh(0.5, 400, 4000), E['send'], 0.5); put(thump(110), E['send'] + 0.9, 0.8)
# returned + joke stamp
put(pop(), E['ret'], 0.7); put(thump(85), E['joke'], 1.0)
# catalog
put(scratch(), E['noJet'], 0.6); put(thump(85), E['noOffer'], 1.0)
# court
put(pop(), E['year'], 0.7); put(knock(), E['gavel1'], 1.0); put(pop(), E['appeal'], 0.7); put(knock(), E['gavel2'], 1.0)
# twist
put(boing(), E['tv700'], 0.7); put(slide_up(), E['kidding'] - 0.05, 0.6); put(ding(), E['kidding'] + 0.35, 0.6)

sr, voice = wavfile.read('voiceover_clean.wav') if False else (None, None)
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', 'voiceover_clean.wav', '-ar', str(SR), '-ac', '1', '-f', 'f32le', 'voice_mono.raw'], check=True)
v = np.fromfile('voice_mono.raw', dtype=np.float32).astype(np.float64)
out = mix[:max(len(v), 1)] * 0.0
L = max(len(v), int(SR * T['duration']))
res = np.zeros(L); res[:len(v)] += v
m = mix[:L] if len(mix) >= L else np.pad(mix, (0, L - len(mix)))
res += m * 0.22                                   # effects sit well under the voice
peak = np.abs(res).max(); res = res / peak * 0.95 if peak > 0.95 else res
wavfile.write('voiceover.wav', SR, (np.clip(res, -1, 1) * 32767).astype(np.int16))
print('events:', {k: round(v, 2) for k, v in E.items()})
print('cuts:', [round(c, 2) for c in CUTS], 'len', round(L / SR, 2))
