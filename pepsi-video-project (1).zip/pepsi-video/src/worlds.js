import * as THREE from 'three';
import {INK, rng, toon, box, cyl, sign, signTex, facade, tower, lampPost, crate, ground, sidewalk, arrow, cloud, paintTex, ink} from './kit.js';
import {character} from './char.js';
import {wordT} from './camera.js';
import {dressStreet, dressOffice, dressHangar, dressLiving} from './dress.js';
import * as P from './props.js';
import EV from './events.json';

export const LOC = {day: 300, office: 600, hangar: 700, court: 800, tv: 900, corp: 1000};

// smooth 0..1 between a and b (seconds)
export const ease = (t, a, b) => { const x = Math.min(1, Math.max(0, (t - a) / (b - a))); return x * x * (3 - 2 * x); };

function street(ox, {lit = false, seed = 1} = {}) {
  const g = new THREE.Group();
  g.add(ground(260, 200, lit ? '#3b3a48' : '#9c958a', {x: ox, z: -30, seed: seed + 2, repeat: 20}));
  // road stripe
  const road = new THREE.Mesh(new THREE.BoxGeometry(260, 0.05, 9), toon(lit ? '#34303e' : '#6e6670'));
  road.position.set(ox, 0.03, 12); g.add(road);
  for (let i = 0; i < 8; i++) g.add(box(0.7, 0.06, 7.6, '#efe7d2', {x: ox - 15.5 + (i % 4) * 1.1 + (i < 4 ? 0 : 31), y: 0.07, z: 12, edges: false, thick: 0.001}));
  for (let i = -12; i < 12; i++) g.add(box(3, 0.06, 0.35, '#e8d28a', {x: ox + i * 10, y: 0.08, z: 12, edges: false, thick: 0.001}));
  g.add(sidewalk(260, {x: ox, z: 5.5, w: 4}));
  g.add(sidewalk(260, {x: ox, z: 18.5, w: 4}));
  // low buildings along the street (both sides of the plaza)
  const cols = ['#c98f6b', '#b8775e', '#d1a47a', '#a86f5c', '#c4a27c', '#9e7b66'];
  const r = rng(seed);
  for (let i = 0; i < 7; i++) {
    for (const side of [-1, 1]) {
      const w = 9 + r() * 3, h = 9 + r() * 10;
      const f = facade({w, h, color: cols[(i + (side > 0 ? 2 : 0)) % cols.length], cols: 3, rows: Math.floor(h / 3.6), seed: seed + i * 7 + side, lit, interior: lit ? '#ffcf7d' : '#3b2b33'});
      f.position.set(ox + side * (18 + i * 12.5), 0, 3);
      g.add(f);
      // side wall + roof to give depth
      g.add(box(w, h, 8, '#8f6c5e', {x: ox + side * (18 + i * 12.5), y: h / 2, z: -1.4, thick: 0.04}));
    }
  }
  // far side of the street
  for (let i = -6; i < 7; i++) {
    const w = 10 + r() * 3, h = 8 + r() * 9;
    const f = facade({w, h, color: cols[(i + 9) % cols.length], cols: 3, rows: Math.floor(h / 3.6), seed: seed + 100 + i, lit, interior: lit ? '#ffcf7d' : '#3b2b33'});
    f.position.set(ox + i * 13, 0, 22); f.rotation.y = Math.PI; g.add(f);
    g.add(box(w, h, 8, '#8f6c5e', {x: ox + i * 13, y: h / 2, z: 26.4, thick: 0.04}));
  }
  // lamp posts
  for (let i = -5; i <= 5; i++) g.add(lampPost(ox + i * 11 + 4, 6.8, 5.5));
  // distant skyline blocks behind the tower
  for (let i = 0; i < 14; i++) {
    const h = 25 + r() * 45, w = 10 + r() * 10;
    g.add(box(w, h, 10, lit ? '#3a3658' : '#b9c3c9', {x: ox - 90 + i * 14 + r() * 4, y: h / 2, z: -80 - r() * 30, thick: 0.08}));
  }
  return g;
}

function room(ox, {w = 14, h = 5, d = 10, wall = '#efe0c4', floor = '#a7764e', seed = 4} = {}) {
  const g = new THREE.Group();
  const wt = paintTex(wall, {seed, stains: 14}); wt.repeat.set(2, 1);
  const walls = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), toon('#ffffff', wt, {side: THREE.BackSide}));
  walls.position.set(ox, h / 2, 0); walls.receiveShadow = true; g.add(walls);
  const ft = paintTex(floor, {seed: seed + 1, stripes: (gg, W, H) => { gg.strokeStyle = 'rgba(60,30,15,0.35)'; gg.lineWidth = 2; for (let i = 0; i < 10; i++) { gg.beginPath(); gg.moveTo(0, i * H / 10); gg.lineTo(W, i * H / 10); gg.stroke(); } }});
  ft.repeat.set(3, 2);
  const fl = new THREE.Mesh(new THREE.BoxGeometry(w - 0.02, 0.1, d - 0.02), toon('#ffffff', ft)); fl.position.set(ox, 0.0, 0); fl.receiveShadow = true; g.add(fl);
  // skirting + ceiling beam for depth
  g.add(box(w, 0.25, 0.15, '#6b4a36', {x: ox, y: 0.12, z: -d / 2 + 0.1, thick: 0.01}));
  return g;
}


// ---------- small helpers ----------
const clamp01 = (x) => Math.min(1, Math.max(0, x));
// pop-in with a little overshoot at time t0
function pop(o, t0, t, dur = 0.35) {
  const x = clamp01((t - t0) / dur);
  o.visible = t >= t0 - 0.001;
  o.scale.setScalar(Math.max(0.001, ease(x, 0, 1) * (1 + 0.16 * Math.sin(Math.PI * x))));
}
// strike pulse (0..1..0) of length len starting at t0
const strike = (t, t0, len = 0.28) => { const d = t - t0; return d > 0 && d < len ? Math.sin((d / len) * Math.PI) : 0; };
function board(w, h, tex, frame = '#5a3a26') {
  const b = box(w, h, 0.12, '#ffffff', {thick: 0.02});
  const f = toon(frame);
  b.material = [f, f, f, f, new THREE.MeshBasicMaterial({map: tex}), f];
  return b;
}
function canvasTex(w, h) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return {c, g: c.getContext('2d'), t};
}
// chalk / flat drawing of a fighter jet (side view), nose to the right
function drawJet(g, x, y, s, fill = '#8e98a3', line = INK) {
  g.save(); g.translate(x, y); g.scale(s, s); g.lineWidth = 5 / s; g.strokeStyle = line; g.fillStyle = fill; g.lineJoin = 'round';
  g.beginPath(); g.moveTo(-90, -6); g.lineTo(-96, -40); g.lineTo(-74, -40); g.lineTo(-52, -8); g.lineTo(60, -14); g.lineTo(110, 2); g.lineTo(60, 14); g.lineTo(-90, 14); g.closePath(); g.fill(); g.stroke();
  g.beginPath(); g.moveTo(-30, 0); g.lineTo(-62, 36); g.lineTo(-20, 36); g.lineTo(18, 0); g.closePath(); g.fillStyle = '#a3abb5'; g.fill(); g.stroke();
  g.beginPath(); g.ellipse(34, -14, 20, 11, -0.1, Math.PI, 0); g.fillStyle = '#7fc6e8'; g.fill(); g.stroke();
  g.restore();
}
// 3D fighter jet, nose toward +x, wheels at y = -1.25
function jet3d() {
  const g = new THREE.Group(); const body = '#8e98a3', dark = '#5d6670';
  const fus = cyl(0.5, 0.5, 6.4, body, {seg: 20}); fus.rotation.z = Math.PI / 2; g.add(fus);
  const nose = cyl(0.04, 0.5, 2.4, body, {seg: 20, x: 4.4}); nose.rotation.z = -Math.PI / 2; g.add(nose);
  const w1 = box(2.4, 0.12, 3.6, '#a3abb5', {x: -0.4, y: -0.1, z: -2.2}); w1.rotation.y = -0.5; g.add(w1);
  const w2 = box(2.4, 0.12, 3.6, '#a3abb5', {x: -0.4, y: -0.1, z: 2.2}); w2.rotation.y = 0.5; g.add(w2);
  g.add(box(1.2, 0.1, 3.4, '#a3abb5', {x: -3.1, y: 0.05}));
  const fin = box(1.5, 1.6, 0.12, '#a3abb5', {x: -3.0, y: 1.0}); fin.rotation.z = 0.35; g.add(fin);
  const cp = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 10), toon('#7fc6e8')); cp.scale.set(1.6, 0.75, 0.85); cp.position.set(1.4, 0.5, 0); ink(cp, 0.02, false); g.add(cp);
  const ex = cyl(0.42, 0.34, 0.5, dark, {x: -3.5, seg: 16}); ex.rotation.z = Math.PI / 2; g.add(ex);
  for (const [x, z] of [[2.0, 0], [-1.2, -0.7], [-1.2, 0.7]]) { g.add(cyl(0.04, 0.04, 0.8, dark, {x, y: -0.85, z, seg: 6})); const wh = cyl(0.2, 0.2, 0.14, '#2b2b2e', {x, y: -1.05, z, seg: 12}); wh.rotation.x = Math.PI / 2; g.add(wh); }
  g.add(box(1.0, 0.04, 0.5, '#c43d32', {x: -0.6, y: 0.3, z: 0, edges: false, thick: 0.001}));
  return g;
}
// weighted-for-sync version of an in-world sign
const mk = (txt, w, h, o = {}) => sign(txt, w, h, Object.assign({font: 'bold 92px Arial, sans-serif'}, o));

export function buildWorld() {
  const W = new THREE.Group();
  const chars = [];
  const ET = Object.fromEntries(Object.entries(EV).map(([k, [key, i]]) => [k, wordT(key, i)]));

  // ======== DAY STREET (the contest + the mailbox) ========
  const D = LOC.day;
  W.add(street(D, {seed: 23}));
  const traffic = dressStreet(W, D, {seed: 23, chars, avoid: [D - 35, D + 20.5, D + 18.3]});
  for (let i = 0; i < 7; i++) W.add(cloud(D - 80 + i * 28, 100 + (i % 3) * 10, -130, 7));
  const bill = sign('KUMPULKAN POIN', 7.5, 2.6, {bg: '#2f6db3', fg: '#fff4dc', w: 900, h: 300, font: 'bold 104px Arial, sans-serif', sub: 'TUKAR DENGAN HADIAH'});
  bill.position.set(D - 35.5, 4.2, 4.2); W.add(bill);
  W.add(cyl(0.1, 0.1, 3, '#3a3a3a', {x: D - 38.5, y: 1.5, z: 4.2}), cyl(0.1, 0.1, 3, '#3a3a3a', {x: D - 32.5, y: 1.5, z: 4.2}));
  const host = character({palette: 'clerk', hat: 'bowler', seed: 41}); host.position.set(D - 35.0, 0.25, 6.4); W.add(host); chars.push(host);
  // pyramid of soda cans (no logos) beside the host
  [[0, 4], [1, 3], [2, 2]].forEach(([row, n]) => { for (let i = 0; i < n; i++) W.add(P.at(cyl(0.17, 0.17, 0.42, ['#2f6db3', '#c43d32', '#f2f0e6'][(i + row) % 3], {y: 0.21, seg: 12}), D - 33.3 + (i - (n - 1) / 2) * 0.38, 0.25 + row * 0.42, 6.0)); });
  const kaos = mk('KAOS', 0.9, 0.55, {bg: '#f2c12e', w: 360, h: 220, font: 'bold 84px Arial, sans-serif'}); kaos.position.set(D - 35.0 - 0.8, 1.05, 6.9); W.add(kaos);
  const kacamata = mk('KACAMATA', 1.4, 0.55, {bg: '#7fc6e8', w: 560, h: 220, font: 'bold 74px Arial, sans-serif'}); kacamata.position.set(D - 35.0 + 0.95, 1.05, 6.9); W.add(kacamata);
  // check scene: cash on a bench, student, big mailbox
  W.add(P.at(P.bench(), D + 16.4, 0.25, 5.0, 0));
  for (let s = 0; s < 3; s++) for (let k = 0; k < 4; k++) W.add(box(0.5, 0.15, 0.26, '#6fa56a', {x: D + 15.9 + s * 0.52, y: 0.9 + k * 0.16, z: 5.0, thick: 0.01, ry: (s - 1) * 0.1}));
  const cashSign = mk('$700.000', 2.4, 0.8, {bg: '#6fa56a', fg: '#fff4dc', w: 600, h: 200, font: 'bold 110px Arial, sans-serif'}); cashSign.position.set(D + 16.4, 2.35, 4.6); W.add(cashSign);
  const mailbox = P.at(P.mailbox(), D + 20.6, 0.25, 5.6); mailbox.scale.setScalar(1.7); W.add(mailbox);
  const kid = character({palette: 'student', hat: 'cap', glasses: true, seed: 61}); kid.position.set(D + 18.5, 0.25, 6.0); W.add(kid); chars.push(kid);
  const chkSign = mk('CEK + 15 POIN', 2.8, 0.8, {bg: '#f2e6cc', w: 700, h: 200, font: 'bold 80px Arial, sans-serif'}); chkSign.position.set(D + 18.5, 2.95, 5.6); W.add(chkSign);
  const env = mk('CEK', 0.55, 0.34, {bg: '#f7f0de', w: 220, h: 136, font: 'bold 60px Arial, sans-serif'}); W.add(env);
  const extraPed = character({palette: 'teal', hat: 'none', seed: 66}); extraPed.position.set(D + 13.4, 0.25, 5.0); W.add(extraPed); chars.push(extraPed);

  // ======== OFFICE (hook + math): student's study ========
  const O = LOC.office;
  W.add(room(O, {w: 16, h: 5.5, d: 11, wall: '#bfe0db', seed: 8}));
  const desk = new THREE.Group();
  desk.add(box(4.2, 0.18, 2, '#8a5a3b', {y: 1.05}));
  for (const [x, z] of [[-1.9, -0.8], [1.9, -0.8], [-1.9, 0.8], [1.9, 0.8]]) desk.add(box(0.15, 1.0, 0.15, '#6b4430', {x, y: 0.5, z}));
  desk.position.set(O - 2.5, 0, 0.5); W.add(desk);
  // calculator on the desk
  W.add(box(0.45, 0.1, 0.65, '#2f5d62', {x: O - 1.7, y: 1.2, z: 0.7, thick: 0.01}));
  const calc = mk('= ?', 0.38, 0.28, {bg: '#bfe3b0', w: 200, h: 150, font: 'bold 80px Arial, sans-serif', border: false}); calc.rotation.x = -Math.PI / 2; calc.position.set(O - 1.7, 1.26, 0.55); W.add(calc);
  // chalkboard
  const ch = canvasTex(640, 360); let chalkKey = '';
  const drawChalk = (mode, p1, p2) => {
    const g = ch.g; g.fillStyle = '#2f4a3a'; g.fillRect(0, 0, 640, 360); g.strokeStyle = '#8a5a3b'; g.lineWidth = 22; g.strokeRect(0, 0, 640, 360);
    g.fillStyle = '#f2ead6'; g.textAlign = 'center';
    if (mode === 'hook') {
      g.font = 'bold 54px Arial, sans-serif'; g.fillText('POIN PEPSI', 320, 86);
      g.globalAlpha = p1; drawJet(g, 330, 220, 1.55, '#f2ead6', '#f2ead6');
      g.font = 'bold 110px Arial, sans-serif'; g.fillStyle = '#ffd66b'; g.fillText('?', 560, 300); g.globalAlpha = 1;
    } else {
      g.globalAlpha = p1; g.font = 'bold 92px Arial, sans-serif'; g.fillStyle = '#f2ead6'; g.fillText('10¢ / POIN', 320, 130);
      g.globalAlpha = p2; g.font = 'bold 70px Arial, sans-serif'; g.fillText('7.000.000 × 10¢', 320, 230);
      g.font = 'bold 100px Arial, sans-serif'; g.fillStyle = '#ffd66b'; g.fillText('= $700.000', 320, 335); g.globalAlpha = 1;
    }
    ch.t.needsUpdate = true;
  };
  drawChalk('hook', 0, 0);
  const chalk = board(4.4, 2.5, ch.t); chalk.position.set(O + 3.2, 2.9, -5.35); W.add(chalk);
  dressOffice(W, O, chars, {p1: 'JET', p2: 'POIN'});
  const student = character({palette: 'student', hat: 'cap', glasses: true, seed: 61}); student.position.set(O + 1.2, 0.05, -3.2); W.add(student); chars.push(student);
  const win = sign('', 2.4, 2.0, {bg: '#bfe3f5', border: true}); win.position.set(O - 5, 3.1, -5.4); W.add(win);

  // ======== HANGAR (the jet) ========
  const Y = LOC.hangar;
  W.add(ground(70, 50, '#7d7d86', {x: Y, z: -5, seed: 14, repeat: 8}));
  W.add(box(30, 10, 10, '#9aa6b4', {x: Y, y: 5, z: -13, thick: 0.04}));
  W.add(box(12, 6.5, 0.4, '#6f7c8c', {x: Y, y: 3.25, z: -7.8, thick: 0.03}));
  const hs = mk('HANGAR', 4.2, 1.0, {bg: '#f2c12e', w: 840, h: 200, font: 'bold 110px Arial, sans-serif'}); hs.position.set(Y, 7.6, -7.4); W.add(hs);
  const jet = jet3d(); jet.position.set(Y, 1.35, 0.6); W.add(jet);
  dressHangar(W, Y, chars);
  const stakesSign = mk('PULUHAN JUTA $', 4.6, 1.05, {bg: '#c43d32', fg: '#fff4dc', w: 920, h: 210, font: 'bold 100px Arial, sans-serif'}); stakesSign.position.set(Y + 0.4, 3.9, 1.6); W.add(stakesSign);
  W.add(cyl(0.06, 0.06, 3.4, '#3a3a3a', {x: Y - 1.6, y: 1.9, z: 1.5}), cyl(0.06, 0.06, 3.4, '#3a3a3a', {x: Y + 2.4, y: 1.9, z: 1.5}));

  // ======== COURTROOM ========
  const J = LOC.court;
  W.add(room(J, {w: 22, h: 8, d: 12, wall: '#7a5a45', floor: '#8a6040', seed: 19}));
  W.add(box(5.6, 0.55, 2.4, '#5a3a26', {x: J, y: 0.275, z: -4.8}));
  W.add(box(5.0, 1.0, 1.2, '#4a2f20', {x: J, y: 1.05, z: -4.0}));
  const judge = character({palette: 'navy', hat: 'none', glasses: true, seed: 85}); judge.position.set(J, 0.6, -4.9); W.add(judge); chars.push(judge);
  const gavel = new THREE.Group();
  const gh = cyl(0.1, 0.1, 0.34, '#6b4430', {seg: 12}); gh.rotation.z = Math.PI / 2; gh.position.set(0.0, 0.32, 0); gavel.add(gh);
  gavel.add(cyl(0.03, 0.03, 0.5, '#8a5a3b', {y: 0.0, seg: 8}));
  gavel.position.set(J + 1.2, 1.62, -3.6); W.add(gavel);
  W.add(box(0.5, 0.06, 0.5, '#2a1a12', {x: J + 1.2, y: 1.58, z: -3.6, thick: 0.01}));
  const seal = mk('PENGADILAN FEDERAL', 6.2, 0.95, {bg: '#e6d39a', w: 1000, h: 154, font: 'bold 72px Arial, sans-serif'}); seal.position.set(J, 6.0, -5.92); W.add(seal);
  const yearSign = mk('1999', 1.9, 1.0, {bg: '#f4ead4', w: 380, h: 200, font: 'bold 110px Arial, sans-serif'}); yearSign.position.set(J - 4.2, 4.2, -5.9); W.add(yearSign);
  const appealSign = mk('BANDING', 2.3, 0.8, {bg: '#c43d32', fg: '#fff4dc', w: 460, h: 160, font: 'bold 84px Arial, sans-serif'}); appealSign.position.set(J + 4.2, 4.2, -5.9); W.add(appealSign);
  for (const [x, c] of [[J - 3.1, '#8a5a3b'], [J + 3.6, '#7a4f33']]) { W.add(P.at(P.desk(2.6, c), x, 0.05, -0.4)); W.add(P.at(P.papers(6, Math.round(x)), x, 1.0, -0.4)); }
  const plaintiff = character({palette: 'student', hat: 'cap', glasses: true, seed: 61}); plaintiff.position.set(J - 3.6, 0.05, -1.5); W.add(plaintiff); chars.push(plaintiff);
  const lawyer = character({palette: 'engineer', hat: 'none', seed: 87}); lawyer.position.set(J - 2.3, 0.05, -1.5); W.add(lawyer); chars.push(lawyer);
  const lawyer2 = character({palette: 'official', hat: 'bowler', seed: 88}); lawyer2.position.set(J + 3.1, 0.05, -1.5); W.add(lawyer2); chars.push(lawyer2);
  const lawyer3 = character({palette: 'clerk', hat: 'none', glasses: true, seed: 89}); lawyer3.position.set(J + 4.5, 0.05, -1.5); W.add(lawyer3); chars.push(lawyer3);
  [[-5.2, 4.0, 'red'], [-3.2, 4.1, 'pink'], [3.2, 4.0, 'mustard'], [5.2, 4.1, 'teal']].forEach(([dx, z, pal], i) => { W.add(P.at(P.bench(), J + dx, 0.05, z + 0.9, 0)); const c = character({palette: pal, hat: ['none', 'top', 'bowler', 'cap'][i], seed: 840 + i}); c.position.set(J + dx, 0.05, z); W.add(c); chars.push(c); });
  for (const x of [J - 9.5, J + 9.5]) { W.add(cyl(0.45, 0.45, 8, '#8f7d6a', {x, y: 4, z: -5.2, seg: 16})); W.add(P.at(P.flag(x < J ? '#c43d32' : '#2f6db3'), x < J ? J - 6.4 : J + 6.4, 0.05, -5.4)); }
  const lampC = new THREE.Mesh(new THREE.SphereGeometry(0.35, 12, 8), new THREE.MeshBasicMaterial({color: '#ffe2a6'})); lampC.position.set(J, 7.0, -1); W.add(lampC); W.add(cyl(0.03, 0.03, 1.2, '#2a2a2a', {x: J, y: 7.6, z: -1}));

  // ======== LIVING ROOM (the TV) ========
  const R = LOC.tv;
  W.add(room(R, {w: 16, h: 5.5, d: 11, wall: '#e8c9a0', floor: '#8a6a4e', seed: 27}));
  const tv = canvasTex(640, 416);
  const drawTV = (land, price, big, kid2, tt) => {
    const g = tv.g;
    const sky = g.createLinearGradient(0, 0, 0, 300); sky.addColorStop(0, '#6fb4ea'); sky.addColorStop(1, '#d6efff'); g.fillStyle = sky; g.fillRect(0, 0, 640, 416);
    g.fillStyle = '#fff3a8'; g.beginPath(); g.arc(90, 70, 34, 0, 7); g.fill();
    g.fillStyle = '#7cc16a'; g.fillRect(0, 300, 640, 116);
    g.fillStyle = '#c98f6b'; g.fillRect(390, 150, 230, 150); g.fillStyle = '#9e6a55'; g.fillRect(380, 138, 250, 16);
    for (let i = 0; i < 4; i++) { g.fillStyle = '#bfe3f5'; g.fillRect(410 + i * 52, 175, 34, 40); g.fillRect(410 + i * 52, 235, 34, 40); }
    g.fillStyle = INK; g.font = 'bold 22px Arial, sans-serif'; g.textAlign = 'center'; g.fillText('SEKOLAH', 505, 127);
    // jet flies in and lands
    const jx = -130 + 350 * land, jy = 40 + 215 * land;
    if (land > 0) drawJet(g, jx, jy, 0.9 + 0.35 * land);
    // teenager waiting at the school
    g.fillStyle = '#c4793d'; g.beginPath(); g.ellipse(330, 290, 16, 24, 0, 0, 7); g.fill(); g.fillStyle = '#f4ecdc'; g.beginPath(); g.arc(330, 255, 13, 0, 7); g.fill();
    // price bar
    if (price > 0) {
      g.globalAlpha = price; g.fillStyle = '#1a1a1a'; g.fillRect(0, 330, 640, 86);
      g.fillStyle = '#ffd66b'; g.textAlign = 'center'; g.font = 'bold 38px Arial, sans-serif'; g.fillText('HARRIER JET', 320, 366);
      g.font = 'bold 44px Arial, sans-serif'; g.fillStyle = big ? '#ff6b5a' : '#ffffff'; g.fillText(big ? '700.000.000 POIN' : '7.000.000 POIN', 320, 405);
      g.globalAlpha = 1;
    }
    if (kid2 > 0) {
      g.save(); g.globalAlpha = kid2; g.translate(500, 60); g.rotate(-0.12); g.fillStyle = '#f2c12e'; g.strokeStyle = INK; g.lineWidth = 6; g.fillRect(-120, -26, 240, 52); g.strokeRect(-120, -26, 240, 52);
      g.fillStyle = INK; g.font = 'bold 34px Arial, sans-serif'; g.fillText('(CUMA BERCANDA)', 0, 12); g.restore();
    }
    // scanlines
    g.fillStyle = 'rgba(0,0,0,0.07)'; for (let y = 0; y < 416; y += 4) g.fillRect(0, y, 640, 1);
    tv.t.needsUpdate = true;
  };
  drawTV(0, 0, false, 0, 0);
  W.add(box(5.6, 1.3, 1.0, '#4a3a2e', {x: R, y: 0.7, z: -4.9}));
  W.add(box(5.2, 3.5, 0.55, '#2a2a2e', {x: R, y: 3.2, z: -5.1, thick: 0.03}));
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(4.7, 3.05), new THREE.MeshBasicMaterial({map: tv.t})); screen.position.set(R, 3.2, -4.81); W.add(screen);
  dressLiving(W, R, chars);

  // ======== CORPORATE OFFICE (returned check + catalog) ========
  const C = LOC.corp;
  W.add(room(C, {w: 16, h: 5.5, d: 11, wall: '#bcd0ec', seed: 33}));
  const cdesk = new THREE.Group();
  cdesk.add(box(4.2, 0.18, 2, '#5a3a26', {y: 1.05}));
  for (const [x, z] of [[-1.9, -0.8], [1.9, -0.8], [-1.9, 0.8], [1.9, 0.8]]) cdesk.add(box(0.15, 1.0, 0.15, '#3f2a1c', {x, y: 0.5, z}));
  cdesk.position.set(C - 1.5, 0, 0.4); W.add(cdesk);
  W.add(P.at(P.phone(), C - 0.6, 1.14, 0.2), P.at(P.papers(6, 9), C - 2.4, 1.14, 0.2), P.at(P.mug('#2f6db3'), C - 1.1, 1.14, 0.9));
  dressOffice(W, C, chars, {p1: 'IKLAN', p2: 'POIN'});
  const cat = canvasTex(640, 400); let catKey = '';
  const drawCat = (jetP, offerP) => {
    const g = cat.g; g.fillStyle = '#f7f0de'; g.fillRect(0, 0, 640, 400); g.strokeStyle = '#8a5a3b'; g.lineWidth = 22; g.strokeRect(0, 0, 640, 400);
    g.fillStyle = INK; g.textAlign = 'center'; g.font = 'bold 50px Arial, sans-serif'; g.fillText('IKLAN ≠ JANJI', 320, 78);
    g.font = 'bold 36px Arial, sans-serif'; g.fillStyle = '#2f6db3'; g.fillText('KATALOG HADIAH', 320, 128);
    g.fillStyle = INK; g.font = 'bold 40px Arial, sans-serif'; g.textAlign = 'left';
    g.fillText('✔  KAOS', 90, 192); g.fillText('✔  KACAMATA HITAM', 90, 248);
    g.fillStyle = '#7a7a7a'; g.fillText('?  JET TEMPUR', 90, 312);
    if (jetP > 0) { g.strokeStyle = '#c43d32'; g.lineWidth = 9; g.beginPath(); g.moveTo(80, 300); g.lineTo(80 + 470 * jetP, 300); g.stroke(); }
    if (offerP > 0) {
      g.save(); g.globalAlpha = offerP; g.translate(430, 335); g.rotate(-0.14); g.strokeStyle = '#c43d32'; g.fillStyle = '#c43d32'; g.lineWidth = 8; g.strokeRect(-190, -34, 380, 68);
      g.font = 'bold 38px Arial, sans-serif'; g.textAlign = 'center'; g.fillText('TIDAK ADA PENAWARAN', 0, 13); g.restore();
    }
    cat.t.needsUpdate = true;
  };
  drawCat(0, 0);
  const catBoard = board(4.4, 2.75, cat.t); catBoard.position.set(C + 3.2, 2.9, -5.35); W.add(catBoard);
  const boss = character({palette: 'official', hat: 'top', seed: 91}); boss.position.set(C - 1.5, 0.05, -1.3); W.add(boss); chars.push(boss);
  const clerk2 = character({palette: 'clerk', hat: 'bowler', glasses: true, seed: 92}); clerk2.position.set(C + 1.4, 0.05, -2.6); W.add(clerk2); chars.push(clerk2);
  const nameplate = mk('PEPSICO', 4.2, 0.9, {bg: '#2f6db3', fg: '#fff4dc', w: 840, h: 180, font: 'bold 100px Arial, sans-serif'}); nameplate.position.set(C - 2.6, 4.45, -5.4); W.add(nameplate);
  const retSign = mk('CEK DIKEMBALIKAN', 3.4, 0.8, {bg: '#f2e6cc', w: 850, h: 200, font: 'bold 80px Arial, sans-serif'}); retSign.position.set(C - 1.4, 3.1, -0.9); W.add(retSign);
  const jokeSign = mk('LELUCON', 2.8, 0.95, {bg: '#f2c12e', fg: '#c43d32', w: 700, h: 240, font: 'bold 120px Arial, sans-serif'}); jokeSign.position.set(C - 0.6, 2.25, 0.2); jokeSign.rotation.z = -0.08; W.add(jokeSign);

  // ======== per-frame update ========
  const update = (t, cam, shot) => {
    for (const c of chars) c.userData.update(t, cam.position);
    traffic(t, cam);
    // hook
    // contest: prizes appear on their words, host waves
    pop(kaos, ET.kaos, t); pop(kacamata, ET.kacamata, t);
    host.userData.armR.rotation.z = shot === 'contest' ? 2.4 + Math.sin(t * 8) * 0.35 : 0;
    // ad / twist TV
    if (shot === 'ad') drawTV(ease(t, ET.tvLand, ET.tvLand + 1.5), ease(t, ET.tvPrice, ET.tvPrice + 0.3), false, 0, t);
    else if (shot === 'twist') drawTV(1, 1, t > ET.tv700, ease(t, ET.kidding, ET.kidding + 0.25), t);
    // stakes sign
    pop(stakesSign, ET.stakesSign, t);
    // math chalk
    const mode = shot === 'math' ? 'math' : 'hook';
    const p1 = shot === 'math' ? ease(t, ET.chalk1, ET.chalk1 + 0.5) : (shot === 'hook' ? ease(t, ET.posterPop - 0.2, ET.posterPop + 0.5) : 1), p2 = shot === 'math' ? ease(t, ET.chalk2, ET.chalk2 + 0.6) : 0;
    const key = mode + p1.toFixed(2) + p2.toFixed(2);
    if (key !== chalkKey) { drawChalk(mode, p1, p2); chalkKey = key; }
    student.userData.armR.rotation.z = shot === 'math' ? 1.9 : 0;
    // check: cash, envelope into the mailbox
    pop(cashSign, ET.cash, t); pop(chkSign, ET.chk, t);
    const u = clamp01((t - ET.send) / 0.9);
    env.visible = t >= ET.send - 0.05 && u < 1;
    env.position.set(D + 18.9 + 1.65 * u, 1.15 + 0.6 * u + Math.sin(Math.PI * u) * 0.5, 6.1 - 0.15 * u); env.scale.setScalar(1 - 0.6 * u);
    kid.userData.armR.rotation.z = (t >= ET.send - 0.4 && shot === 'check') ? 2.2 : 0;
    // but: returned check + JOKE stamp
    pop(retSign, ET.ret, t); pop(jokeSign, ET.joke, t, 0.25);
    boss.userData.armR.rotation.z = shot === 'but' ? 1.3 + Math.sin(t * 5) * 0.12 : 0;
    // catalog: strike through the jet row, then the verdict stamp
    const jp = shot === 'yousee' ? ease(t, ET.noJet, ET.noJet + 0.5) : 0, op = shot === 'yousee' ? ease(t, ET.noOffer, ET.noOffer + 0.3) : 0;
    const ck = jp.toFixed(2) + op.toFixed(2); if (ck !== catKey) { drawCat(jp, op); catKey = ck; }
    // court: year sign, gavel strikes, appeal sign
    pop(yearSign, ET.year, t); pop(appealSign, ET.appeal, t);
    gavel.rotation.z = 0.9 * (1 - Math.max(strike(t, ET.gavel1), strike(t, ET.gavel2)));
    judge.userData.armR.rotation.z = shot === 'so' ? 0.5 + Math.max(strike(t, ET.gavel1), strike(t, ET.gavel2)) * 0.6 : 0;
  };
  return {group: W, update};
}
